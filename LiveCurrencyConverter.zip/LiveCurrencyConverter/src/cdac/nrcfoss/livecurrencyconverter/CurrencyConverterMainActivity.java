package cdac.nrcfoss.livecurrencyconverter;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.view.Menu;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class CurrencyConverterMainActivity extends Activity {
	
	//Variable declarations
	Button btnExit,btnConvert;
	EditText edtFromCurrency;
	TextView txtHeader,txtResult;
	Typeface face;
	ListView lstCurrencies;
	Spinner spnFromCurrency,spnToCurrency;
	String[] currencies;
	CurrencyMap map;
	DownloadData downloader;
	ConnectivityManager connMgr;
	String url;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_currency_converter_main);
		initializer();
	}
	
	//Custom method to perform all initialization tasks on Activity creation
	void initializer(){
		
		//Bindings of Layout Views into Source Code for Event assignment 
		btnExit = (Button)findViewById(R.id.btnExit);
		btnConvert = (Button)findViewById(R.id.btnConvert);
		txtHeader = (TextView)findViewById(R.id.txtHeader);
		txtResult = (TextView)findViewById(R.id.txtResult);
		edtFromCurrency = (EditText)findViewById(R.id.edtFromCurrency);
		spnFromCurrency = (Spinner)findViewById(R.id.spnFromCurrency);
		spnToCurrency = (Spinner)findViewById(R.id.spnToCurrency);
		
		
		
		
		face = Typeface.createFromAsset(getAssets(), "fonts/RepublicSC.ttf");
		txtHeader.setTypeface(face);
		//txtHeader.setVisibility(View.INVISIBLE);
		txtHeader.startAnimation(AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left));
		txtHeader.setVisibility(View.VISIBLE);
		
		face = Typeface.createFromAsset(getAssets(), "fonts/charles.ttf");
		btnConvert.setTypeface(face);
		btnExit.setTypeface(face);
		
		edtFromCurrency.clearFocus();
		spnFromCurrency.requestFocus();
		//Currencies String Array Resource loading from currencies.xml file
		currencies = getResources().getStringArray(R.array.currencies);
		
		//CurrencyMap class object initialization
		map = new CurrencyMap();
		 
		
		//Binding data to spinners
		spnFromCurrency.setAdapter(new ArrayAdapter<String>(CurrencyConverterMainActivity.this,android.R.layout.simple_dropdown_item_1line , currencies));
		spnToCurrency.setAdapter(new ArrayAdapter<String>(CurrencyConverterMainActivity.this,android.R.layout.simple_dropdown_item_1line , currencies));
		
		//Convert Button's click listener.
		btnConvert.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				 
						connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
					    NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
					    
					    if(spnFromCurrency.getSelectedItemPosition()==spnToCurrency.getSelectedItemPosition()){
					    	txtResult.setText(getResultString("1"));
			    			txtResult.startAnimation(AnimationUtils.loadAnimation(CurrencyConverterMainActivity.this, android.R.anim.slide_in_left));
			    			txtResult.setVisibility(View.VISIBLE);
					    }else{	
					    	if (networkInfo != null && networkInfo.isConnected()) {	
					    		url = "http://www.google.com/finance/converter?a=1&from="+map.currencyMap.get(currencies[spnFromCurrency.getSelectedItemPosition()])+"&to="+map.currencyMap.get(currencies[spnToCurrency.getSelectedItemPosition()])+"&submit=Convert";
					    		new DownloadData(CurrencyConverterMainActivity.this).execute(url);
					    	}else{
							        Toast.makeText(CurrencyConverterMainActivity.this, "No Internet Connection Available !! Please Connect & Retry", Toast.LENGTH_LONG).show();
					    	}
						}  	
			}
		});
		
		//Exit Button's on click listener to perform killing of Activity.
		btnExit.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				CurrencyConverterMainActivity.this.finish();
				
			}
		});
		
		
	}
	
	public String getResultString(String rate){
		if(edtFromCurrency.getText().toString().equals(""))
			return "1 "+currencies[spnFromCurrency.getSelectedItemPosition()]+"\n=\n"+rate+" "+currencies[spnToCurrency.getSelectedItemPosition()];
		else
			
			return edtFromCurrency.getText().toString()+" "+currencies[spnFromCurrency.getSelectedItemPosition()]+"\n=\n"+Double.parseDouble(rate)*Double.parseDouble(edtFromCurrency.getText().toString())+" "+currencies[spnToCurrency.getSelectedItemPosition()];
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.currency_converter_main, menu);
		return true;
	}

}
