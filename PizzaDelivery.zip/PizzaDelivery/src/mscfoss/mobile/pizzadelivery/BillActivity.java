package mscfoss.mobile.pizzadelivery;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class BillActivity extends Activity{

	Button btnBack;
	TextView txtBill;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_bill);
		initializer();
	}
	
	public void initializer(){
		
		btnBack = (Button)findViewById(R.id.btnBack);
		txtBill = (TextView)findViewById(R.id.txtBill);
				
		String farmFresh,veggieDelight,doubleDecker,cheezyBites;
		
		farmFresh = getIntent().getStringExtra("farmFresh");
		veggieDelight = getIntent().getStringExtra("veggieDelight");
		doubleDecker = getIntent().getStringExtra("doubleDecker");
		cheezyBites = getIntent().getStringExtra("cheezyBites");
		
		int total = Integer.parseInt(farmFresh)*100 + Integer.parseInt(veggieDelight)*200 + Integer.parseInt(doubleDecker)*300 + Integer.parseInt(cheezyBites)*400;
		
		txtBill.setText("QUANTITY PURCHASED\n\nFarm Fresh : "+farmFresh+"\nVeggie Delight : "+veggieDelight+"\nDouble Decker : "+doubleDecker+"\nCheezyBites : "+cheezyBites+"\n\nTOTAL AMOUNT = Rs."+total+"/-" );
		
		
		btnBack.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				BillActivity.this.finish();
			}
		});
	}
	
}