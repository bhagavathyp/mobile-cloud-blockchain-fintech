package mscfoss.mobile.pizzadelivery;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity implements OnCheckedChangeListener{
	
	Button btnBuy, btnExit;
	CheckBox chkFarmFresh,chkVeggieDelight,chkDoubleDecker,chkCheezyBites;
	EditText edtFarmFresh,edtVeggieDelight,edtDoubleDecker,edtCheezyBites;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		initializer();
	}
	
	public void initializer(){
		btnBuy = (Button)findViewById(R.id.btnBuy);
		btnExit = (Button)findViewById(R.id.btnExit);
		chkFarmFresh = (CheckBox)findViewById(R.id.chkFarmFresh);
		chkVeggieDelight = (CheckBox)findViewById(R.id.chkVeggieDelight);
		chkDoubleDecker = (CheckBox)findViewById(R.id.chkDoubleDecker);
		chkCheezyBites = (CheckBox)findViewById(R.id.chkCheezyBites);
		edtFarmFresh = (EditText)findViewById(R.id.edtFarmFresh);
		edtVeggieDelight = (EditText)findViewById(R.id.edtVeggieDelight);
		edtDoubleDecker = (EditText)findViewById(R.id.edtDoubleDecker);
		edtCheezyBites = (EditText)findViewById(R.id.edtCheezyBites);
		
		chkFarmFresh.setOnCheckedChangeListener(this);
		chkVeggieDelight.setOnCheckedChangeListener(this);
		chkDoubleDecker.setOnCheckedChangeListener(this);
		chkCheezyBites.setOnCheckedChangeListener(this);
		
		btnBuy.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String farmFresh="0",veggieDelight="0",doubleDecker="0",cheezyBites="0";
				int toast=0;
				
				if(chkVeggieDelight.isChecked()){
					veggieDelight = edtVeggieDelight.getText().toString();
					if(veggieDelight.trim().equals("")){
						Toast.makeText(MainActivity.this, "Enter Some Quantity for Veggie Delight", Toast.LENGTH_LONG).show();
						toast=1;
					}
				}	
				if(chkFarmFresh.isChecked()){
					farmFresh = edtFarmFresh.getText().toString();
					if(farmFresh.trim().equals("")){
						Toast.makeText(MainActivity.this, "Enter Some Quantity for Farm Fresh  ", Toast.LENGTH_LONG).show();
						toast=1;
					}
				}	
				if(chkDoubleDecker.isChecked()){
					doubleDecker = edtDoubleDecker.getText().toString();
					if(doubleDecker.trim().equals("")){
						Toast.makeText(MainActivity.this, "Enter Some Quantity for Double Decker", Toast.LENGTH_LONG).show();
						toast=1;
					}
				}	
				if(chkCheezyBites.isChecked()){
					cheezyBites = edtCheezyBites.getText().toString();
					if(cheezyBites.trim().equals("")){
						Toast.makeText(MainActivity.this, "Enter Some Quantity for Cheezy Bites", Toast.LENGTH_LONG).show();
						toast=1;
					}
				}
				
				if(toast!=1){
					Intent billActivityOpener = new Intent(MainActivity.this,BillActivity.class);
					billActivityOpener.putExtra("farmFresh", farmFresh);
					billActivityOpener.putExtra("veggieDelight",veggieDelight);
					billActivityOpener.putExtra("doubleDecker",doubleDecker);
					billActivityOpener.putExtra("cheezyBites",cheezyBites);
					startActivity(billActivityOpener);
				}
			}
		});
		
		btnExit.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				MainActivity.this.finish();
			}
		});
	}
	
	@Override
	public void onCheckedChanged(CompoundButton chkView, boolean isChecked) {
		switch(chkView.getId()){
			case R.id.chkFarmFresh :
				if(isChecked)
					edtFarmFresh.setVisibility(View.VISIBLE);
				else	
					edtFarmFresh.setVisibility(View.INVISIBLE);
				break;
			case R.id.chkVeggieDelight :	
				if(isChecked)
					edtVeggieDelight.setVisibility(View.VISIBLE);
				else	
					edtVeggieDelight.setVisibility(View.INVISIBLE);
				break;
			case R.id.chkDoubleDecker :	
				if(isChecked)
					edtDoubleDecker.setVisibility(View.VISIBLE);
				else	
					edtDoubleDecker.setVisibility(View.INVISIBLE);
				break;
			case R.id.chkCheezyBites :	
				if(isChecked)
					edtCheezyBites.setVisibility(View.VISIBLE);
				else	
					edtCheezyBites.setVisibility(View.INVISIBLE);	
				break;
		}
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	

}
