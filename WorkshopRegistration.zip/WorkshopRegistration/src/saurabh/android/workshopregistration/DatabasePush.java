package saurabh.android.workshopregistration;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.AsyncTask;
import android.widget.Toast;


public class DatabasePush extends AsyncTask<ContentValues, String, String>{

	Context activityContext;
	String TABLE_NAME;

	public DatabasePush(Context activityContext,String tableName) {
		super();
		this.activityContext = activityContext;
		this.TABLE_NAME = tableName;
	}

	@Override
	protected String doInBackground(ContentValues... params) {
		
		try{
			SQLiteDatabase db = new MySQLiteOpenHelper(activityContext, null, null, 1).getWritableDatabase();
			ContentValues cv = params[0];
			db.insert(TABLE_NAME, null, cv);
		}catch(SQLiteException e){
			return "Record Not Entered";
		}
		
		return "Candidate Successfully Registered";
	}
	
	@Override
	protected void onPostExecute(String result) {
		super.onPostExecute(result);
		Toast.makeText(activityContext, result, Toast.LENGTH_LONG).show();
	}

}
