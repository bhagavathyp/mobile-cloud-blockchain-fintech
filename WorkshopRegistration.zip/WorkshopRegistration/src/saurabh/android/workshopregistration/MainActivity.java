package saurabh.android.workshopregistration;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import static saurabh.android.workshopregistration.MySQLiteOpenHelper.*;

public class MainActivity extends Activity {
	
	EditText edtName,edtMobile,edtEmail;
	Spinner spnBranch;
	Button btnRegister,btnViewCandidates,btnExit;
	
	String[] branch = {"Computer Science","Electronics","Electrical","Mechanical","Civil","Ceramics","Metallurgy","Physics"};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		initializer();
	}
	
	void initializer(){
		edtName = (EditText)findViewById(R.id.edtName);
		edtMobile = (EditText)findViewById(R.id.edtMobile);
		edtEmail = (EditText)findViewById(R.id.edtEmail);
		
		spnBranch = (Spinner)findViewById(R.id.spnBranch);
		
		btnRegister = (Button)findViewById(R.id.btnRegister);
		btnViewCandidates = (Button)findViewById(R.id.btnViewCandidates);
		btnExit = (Button)findViewById(R.id.btnExit);
		
		spnBranch.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_item, branch));
		
		btnRegister.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				
				ContentValues cv = new ContentValues();
				cv.put(COL_NAME, edtName.getText().toString());
				cv.put(COL_MOBILE, edtMobile.getText().toString());
				cv.put(COL_BRANCH, branch[spnBranch.getSelectedItemPosition()]);
				cv.put(COL_EMAIL, edtEmail.getText().toString());
				
				new DatabasePush(MainActivity.this, TABLE_NAME).execute(cv);
				
				edtName.setText("");
				edtMobile.setText("");
				edtEmail.setText("");
				spnBranch.setSelection(0);
				
			}
		});
		btnViewCandidates.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent viewCandidateActivityOpener = new Intent();
				viewCandidateActivityOpener.setClassName("saurabh.android.workshopregistration", "saurabh.android.workshopregistration.ViewCandidatesActivity");
				startActivity(viewCandidateActivityOpener);
				
			}
		});
		btnExit.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				MainActivity.this.finish();
				
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
