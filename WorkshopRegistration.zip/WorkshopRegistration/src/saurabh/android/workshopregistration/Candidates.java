package saurabh.android.workshopregistration;

public class Candidates {
	
	String name,mobileNo,Branch,email;

	public Candidates(String name, String mobileNo, String branch, String email) {
		super();
		this.name = name;
		this.mobileNo = mobileNo;
		Branch = branch;
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getBranch() {
		return Branch;
	}

	public void setBranch(String branch) {
		Branch = branch;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
