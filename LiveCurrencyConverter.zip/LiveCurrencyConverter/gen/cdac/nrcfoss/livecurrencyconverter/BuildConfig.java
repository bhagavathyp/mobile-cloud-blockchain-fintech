/** Automatically generated file. DO NOT MODIFY */
package cdac.nrcfoss.livecurrencyconverter;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}