package cdac.nrcfoss.livecurrencyconverter;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.TextView;

public class DownloadData extends AsyncTask<String,Integer,String>{
	
	Context mainActivityContext;
	TextView txtResult;
	EditText edtCurrencyValue;
	
	String rate;
	
	public DownloadData(Context ctx){
		mainActivityContext=ctx;
	}

	@Override
	protected String doInBackground(String... url) {
		try {
			return downloadUrl(url[0]);
		} catch (IOException e) {
			e.printStackTrace();
			return "Unable to Download data.";
		}
		
	}
	
	
	// Given a URL, establishes an HttpUrlConnection and retrieves
	// the web page content as a InputStream, which it returns as
	// a string.
	private String downloadUrl(String myurl) throws IOException {
	    InputStream is = null;
	    // Only display the first 500 characters of the retrieved
	    // web page content.
	    int len = 2000;
	        
	    try {
	        URL url = new URL(myurl);
	        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	        conn.setReadTimeout(10000 /* milliseconds */);
	        conn.setConnectTimeout(15000 /* milliseconds */);
	        conn.setRequestMethod("GET");
	        conn.setDoInput(true);
	        // Starts the query
	        conn.connect();
	        int response = conn.getResponseCode();
	        if(response==HttpURLConnection.HTTP_OK)
	        	is = conn.getInputStream();

	        // Convert the InputStream into a string
	        String contentAsString = readIt(is, len);
	        return contentAsString;
	        
	    // Makes sure that the InputStream is closed after the app is
	    // finished using it.
	    } finally {
	        if (is != null) {
	            is.close();
	        } 
	    }
	}
	
	public String readIt(InputStream stream, int len) throws IOException, UnsupportedEncodingException {
	   Reader reader = null;
	   reader = new InputStreamReader(stream, "UTF-8");        
	   
	    
		int charRead;
        String str = "";
        char[] inputBuffer = new char[len];          
        try{
           while((charRead = reader.read(inputBuffer))>0)
           {                    
               //---convert the chars to a String---
               String readString = String.copyValueOf(inputBuffer, 0, charRead);                    
               str += readString;
               inputBuffer = new char[len];
           }
           
           
        }catch (IOException e) {
           e.printStackTrace();
           return "1";
        }    
       return str;        
	}


	@Override
	protected void onPostExecute(String result) {
		super.onPostExecute(result);
		txtResult = (TextView)((Activity)mainActivityContext).findViewById(R.id.txtResult);
		
			if(result.equals("Unable to Download data."))
				txtResult.setText(result);
			else{	
				rate = result.substring(result.indexOf("bld>")+4,result.indexOf("</span>")-3);
				txtResult.setText(((CurrencyConverterMainActivity)mainActivityContext).getResultString(rate));
			}	
		txtResult.startAnimation(AnimationUtils.loadAnimation(mainActivityContext, android.R.anim.slide_in_left));
		txtResult.setVisibility(View.VISIBLE);
	}
	
}