package saurabh.android.workshopregistration;

import static saurabh.android.workshopregistration.MySQLiteOpenHelper.COL_BRANCH;
import static saurabh.android.workshopregistration.MySQLiteOpenHelper.COL_EMAIL;
import static saurabh.android.workshopregistration.MySQLiteOpenHelper.COL_MOBILE;
import static saurabh.android.workshopregistration.MySQLiteOpenHelper.COL_NAME;
import static saurabh.android.workshopregistration.MySQLiteOpenHelper.TABLE_NAME;

import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.AsyncTask;

public class DataBasePull extends AsyncTask<String, String, ArrayList<Candidates>>{

	Context activityContext;

	public DataBasePull(Context activityContext) {
		super();
		this.activityContext = activityContext;
	}

	@Override
	protected ArrayList<Candidates> doInBackground(String... params) {
		
		try{
			SQLiteDatabase db = new MySQLiteOpenHelper(activityContext, null, null, 1).getReadableDatabase();
			Cursor c = db.query(TABLE_NAME, new String[]{COL_NAME,COL_MOBILE,COL_BRANCH,COL_EMAIL}, null, null, null, null, null);
			
			ArrayList<Candidates> candidates = new ArrayList<Candidates>();
			
			if(c!=null && !c.isAfterLast())
				c.moveToFirst();
			
			do{
				candidates.add(new Candidates(c.getString(0), c.getString(1), c.getString(2), c.getString(3)));
				c.moveToNext();
			}while(!c.isAfterLast());
			
			if(c!=null)
				c.close();
			
			return candidates;
		}catch(SQLiteException e){
			return null;
		}
		
		
	}
	
	@Override
	protected void onPostExecute(ArrayList<Candidates> candidates) {
		super.onPostExecute(candidates);
		
		((ViewCandidatesActivity)activityContext).candidates = candidates;
		((ViewCandidatesActivity)activityContext).bindDatatoUI();
		
	}
	
	

}
