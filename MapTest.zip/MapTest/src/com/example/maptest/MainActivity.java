package com.example.maptest;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.MapView;

import android.os.Bundle;
import android.app.Activity;
import android.support.v4.app.FragmentActivity;
import android.view.Menu;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {
	

	Button btnExit,btnNormal,btnSatellite,btnTerrain;
	private GoogleMap myMap;
	
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		initializer(savedInstanceState);
	}
	
	public void initializer(Bundle savedInstanceState){
		btnExit = (Button)findViewById(R.id.btnExit);
		btnNormal = (Button)findViewById(R.id.btnNormal);
		btnSatellite = (Button)findViewById(R.id.btnSatellite);
		btnTerrain = (Button)findViewById(R.id.btnTerrain);
		
		myMap = ((MapFragment) getFragmentManager().findFragmentById(R.id.map)).getMap();
		
		btnNormal.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				myMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
			}
		});
		btnSatellite.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				myMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
			}
		});
		btnTerrain.setOnClickListener(new View.OnClickListener() {
	
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				myMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
			}
		});
		
		btnExit.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				MainActivity.this.finish();
				
			}
		});
	}
	
	/* (non-Javadoc)
	 * @see android.app.Activity#onDestroy()
	 */
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		//myMapView.onDestroy();
	}

	/* (non-Javadoc)
	 * @see android.app.Activity#onLowMemory()
	 */
	@Override
	public void onLowMemory() {
		// TODO Auto-generated method stub
		super.onLowMemory();
		//myMapView.onLowMemory();
	}

	/* (non-Javadoc)
	 * @see android.app.Activity#onPause()
	 */
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		//myMapView.onPause();
	}
	 @Override
	    public void onSaveInstanceState(Bundle outState) {
	        super.onSaveInstanceState(outState);
	       // myMapView.onSaveInstanceState(outState);
	    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
