package saurabh.android.workshopregistration;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class ViewCandidatesActivity extends Activity{
	
	Button btnBack;
	ListView lstCandidates;
	ArrayList<Candidates> candidates;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_view_candidates);
		new DataBasePull(ViewCandidatesActivity.this).execute("DataBasePull");
		initializer();
	}
	
	void initializer(){
		
		btnBack = (Button)findViewById(R.id.btnBack);
		lstCandidates = (ListView)findViewById(R.id.lstCandidates);
		
		btnBack.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				ViewCandidatesActivity.this.finish();
				
			}
		});	
	}
	
	void bindDatatoUI(){
		lstCandidates.setAdapter(new CustomListAdapter());
	}
	
	public class CustomListAdapter extends BaseAdapter{

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return candidates.size();
		}

		@Override
		public Object getItem(int arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int arg0) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View listItemView; 
			
			
			if(convertView==null){
				listItemView = getLayoutInflater().inflate(R.layout.candidates_list_item, parent, false);
			}else{
				listItemView = convertView;
			}
			
			TextView txtName = (TextView)listItemView.findViewById(R.id.txtName);
			TextView txtMobile = (TextView)listItemView.findViewById(R.id.txtMobile);
			TextView txtBranch = (TextView)listItemView.findViewById(R.id.txtBranch);
			TextView txtEmail = (TextView)listItemView.findViewById(R.id.txtEmail);
			
			txtName.setText("Name = "+candidates.get(position).getName());
			txtMobile.setText("Mobile = "+candidates.get(position).getMobileNo());
			txtBranch.setText("Branch = "+candidates.get(position).getBranch());
			txtEmail.setText("Email = "+candidates.get(position).getEmail());
			
			
			return listItemView;
		}
		
	}

}
